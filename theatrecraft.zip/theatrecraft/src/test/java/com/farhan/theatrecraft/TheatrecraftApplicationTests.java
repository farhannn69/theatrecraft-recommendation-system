package com.farhan.theatrecraft;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TheatrecraftApplicationTests {

	@Test
	void contextLoads() {
	}

}
