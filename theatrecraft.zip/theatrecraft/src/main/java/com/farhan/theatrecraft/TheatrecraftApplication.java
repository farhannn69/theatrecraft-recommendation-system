package com.farhan.theatrecraft;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TheatrecraftApplication {

	public static void main(String[] args) {
		SpringApplication.run(TheatrecraftApplication.class, args);
	}

}
